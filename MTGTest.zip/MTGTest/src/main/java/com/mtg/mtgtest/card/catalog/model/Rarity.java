package com.mtg.mtgtest.card.catalog.model;

public enum Rarity {
    COMMON, UNCOMMON, RARE, MYTHIC_RARE
}
