package com.mtg.mtgtest.card.catalog.model;

public enum Type {
    LAND, CREATURE, ENCHANTMENT, INSTANT, SORCERY
}
